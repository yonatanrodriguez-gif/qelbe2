"use client";

import { useState, useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════════════
   QELBE — OPCIÓN B: "BOLD & EXPRESIVA"
   Estética: Paleta Qelbe a tope. Bloques de color,
   formas geométricas, textura grain, diagonales,
   energía y personalidad. Anti-genérico.
   ═══════════════════════════════════════════════════════════════ */

const useInView = (threshold = 0.12) => {
  const ref = useRef(null);
  const [v, setV] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(true); o.unobserve(el); } }, { threshold });
    o.observe(el);
    return () => o.disconnect();
  }, []);
  return [ref, v];
};

const Reveal = ({ children, delay = 0, style = {}, className = "" }) => {
  const [r, v] = useInView();
  return (
    <div ref={r} className={className} style={{
      ...style,
      opacity: v ? 1 : 0,
      transform: v ? "translateY(0) rotate(0)" : "translateY(30px) rotate(-.5deg)",
      transition: `all .7s cubic-bezier(.16,1,.3,1) ${delay}s`,
    }}>{children}</div>
  );
};

const Countdown = ({ dark }) => {
  const getDeadline = () => {
    const n = new Date();
    let d = new Date(n.getFullYear(), n.getMonth(), 27, 23, 59, 59);
    if (n > d) d = new Date(n.getFullYear(), n.getMonth() + 1, 27, 23, 59, 59);
    return d;
  };
  const [dl] = useState(getDeadline);
  const [t, setT] = useState({ d: 0, h: 0, m: 0, s: 0 });
  useEffect(() => {
    const tick = () => {
      const ms = dl - new Date();
      if (ms <= 0) return;
      const s = Math.floor(ms / 1000), m = Math.floor(s / 60), h = Math.floor(m / 60), d = Math.floor(h / 24);
      setT({ d, h: h % 24, m: m % 60, s: s % 60 });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [dl]);
  const pad = n => String(n).padStart(2, "0");
  return (
    <div style={{ display: "flex", gap: "6px" }}>
      {[
        { v: t.d, l: "d" }, { v: t.h, l: "h" },
        { v: t.m, l: "m" }, { v: t.s, l: "s" }
      ].map((u, i) => (
        <div key={i} style={{
          background: dark ? "rgba(0,0,0,.15)" : "rgba(255,255,255,.15)",
          borderRadius: "8px", padding: "8px 10px", textAlign: "center",
          minWidth: "42px",
        }}>
          <div style={{
            fontFamily: "'Space Mono',monospace", fontSize: "clamp(16px,2.5vw,22px)",
            fontWeight: 700, color: dark ? "#000" : "#fff", lineHeight: 1
          }}>{pad(u.v)}</div>
          <div style={{
            fontSize: "9px", color: dark ? "rgba(0,0,0,.4)" : "rgba(255,255,255,.5)",
            textTransform: "uppercase", letterSpacing: ".12em", marginTop: "2px",
            fontFamily: "'Space Mono',monospace"
          }}>{u.l}</div>
        </div>
      ))}
    </div>
  );
};

export default function QelbeBold() {
  const [openFaq, setOpenFaq] = useState(null);
  const [hoveredCourse, setHoveredCourse] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState("pack3");

  const courses = [
    {
      id: "retos", num: "01", color: "#F0B400", bg: "#F0B400",
      title: "Retos y riesgos de mi negocio familiar",
      hook: "La radiografía",
      desc: "Identifica los riesgos reales de tu MYPE familiar y las acciones concretas para cada reto. Diagnóstico inmediato.",
      modules: ["Diagnóstico de nivel de riesgo", "Complejidad de tu MYPE", "Riesgos y retos específicos", "Acción detrás de cada reto", "Guías de aplicación inmediata"],
      forWho: "Para dueños que sospechan vulnerabilidades pero no saben cuáles ni cómo priorizarlas.",
      link: "https://www.paypal.com/ncp/payment/P3M3BYZ4S6T2C"
    },
    {
      id: "liderar", num: "02", color: "#84AE25", bg: "#84AE25",
      title: "Liderar a mi familia empresaria",
      hook: "La ejecución",
      desc: "Construye un liderazgo que sepa navegar entre familia y empresa. Enfoque sistémico, herramientas reales.",
      modules: ["Autodiagnóstico de liderazgo", "Entender mi sistema empresarial-familiar", "Aclarar relaciones", "Guiar a mi familia empresaria", "Hoja de ruta personalizada"],
      forWho: "Para quien lidera o va a liderar y siente que las dinámicas familiares complican todo.",
      link: "https://www.paypal.com/ncp/payment/CSTLA6U6PG5ZU"
    },
    {
      id: "retiro", num: "03", color: "#E9781C", bg: "#E9781C",
      title: "Estructurando mi retiro",
      hook: "Estructurar",
      desc: "Planifica tu salida sin que el negocio se detenga. Retos, desafíos e implicaciones para tu plan de acción.",
      modules: ["Autoevaluación sobre el retiro", "¿Estoy preparado?", "Detonadores internos", "Implicaciones del entorno", "Plan de acción inicial"],
      forWho: "Para fundadores que llevan años pensando en retirarse pero no saben por dónde empezar.",
      link: "https://www.paypal.com/ncp/payment/PM8Q4GVXNZ9Y2"
    }
  ];

  const packs = [
    { key: "single", label: "1 Curso", price: 1469, original: 2938, pct: "50%", perCourse: "$1,469", popular: false, courseColor: "#84AE25" },
    { key: "pack2", label: "2 Cursos", price: 2497, original: 5876, pct: "57%", perCourse: "$1,249", popular: false, courseColor: "#F0B400" },
    { key: "pack3", label: "3 Cursos", price: 3746, original: 8814, pct: "57%", perCourse: "$1,249", popular: true, courseColor: "#E9781C" }
  ];

  const testimonials = [
    { q: "Por fin tengo un marco para separar las discusiones de familia de las decisiones de negocio.", name: "Mariana G.", ctx: "Fundadora · Alimentos", color: "#84AE25", img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Aon5hylLp1niFgnEf1aRM9UsgVVU2O.png" },
    { q: "Entendí que liderar el negocio no es solo gestionar la empresa. Es también liderar a mi familia.", name: "Luis M.", ctx: "2ª gen. · Comercializadora", color: "#F0B400", img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-OV7B7epgQuPM7eZpOvWgmnWWuHgZd5.png" },
    { q: "Las guías de aplicación son brutalmente prácticas. Al siguiente lunes ya estaba usándolas.", name: "Ismael T.", ctx: "Director · Taller industrial", color: "#E9781C", img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-wj6VYbd3aARslfU1k1EJckQsZ9edaw.png" }
  ];

  const faqs = [
    { q: "¿Cómo accedo después de pagar?", a: "Recibes acceso a Qelbe Xchool por correo en máximo 48h hábiles." },
    { q: "¿Cuánto tiempo tengo?", a: "Un mes completo por curso. Tú eliges el mes (junio–noviembre 2025). ~12h de contenido por curso." },
    { q: "¿Si compro pack, los hago todos a la vez?", a: "Cada curso se activa por separado en el mes que tú elijas. Puedes hacerlos consecutivos o simultáneos." },
    { q: "¿Certificado?", a: "Sí, uno digital por cada curso completado." },
    { q: "¿Es para negocios MUY pequeños?", a: "Especialmente. Diseñado para MYPEs familiares. Da igual si tienes 3 o 50 personas." },
    { q: "¿Factura?", a: "Sí. Escribe a hola@qelbe.com con tus datos fiscales." }
  ];

  const css = `
    @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Corben:wght@400;700&family=Manrope:wght@400;500;600;700;800&display=swap');

    *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
    html { scroll-behavior:smooth; }

    .bo {
      font-family: 'Manrope', sans-serif;
      color: #1a1a1a;
      background: #FFFDF8;
      overflow-x: hidden;
    }
    .bo h1, .bo h2, .bo h3 {
      font-family: 'Corben', cursive;
      font-weight: 700;
    }

    /* ── grain overlay ── */
    .bo::after {
      content: '';
      position: fixed; inset: 0; z-index: 9999;
      pointer-events: none;
      opacity: .03;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
      background-size: 128px;
    }

    /* ── NAV ── */
    .bo-nav {
      position: sticky; top: 0; z-index: 200;
      display: flex; align-items: center; justify-content: space-between;
      padding: 10px clamp(16px,4vw,40px);
      background: rgba(255,253,248,.9);
      backdrop-filter: blur(16px);
      border-bottom: 3px solid #000;
    }
    .bo-nav-logo {
      font-family: 'Inter', sans-serif;
      font-weight: 800; font-size: 24px; color: #000;
      text-decoration: none; letter-spacing: -.03em;
    }
    .bo-nav-right { display:flex; align-items:center; gap:8px; }
    .bo-nav-link {
      padding: 8px 14px;
      font-size: 13px; font-weight: 600; color: #000;
      text-decoration: none; border-radius: 6px;
      transition: background .2s;
    }
    .bo-nav-link:hover { background: rgba(0,0,0,.05); }
    .bo-nav-cta {
      padding: 10px 20px;
      background: var(--teal, #F0B400); color: #000;
      font-size: 13px; font-weight: 700;
      border: none; border-radius: 6px;
      cursor: pointer; text-decoration: none;
      transition: transform .15s;
    }
    .bo-nav-cta:hover { transform:scale(1.03); }

    /* ── HERO ── */
    .bo-hero {
      position: relative;
      padding: clamp(48px,8vw,100px) clamp(16px,4vw,40px) clamp(48px,6vw,80px);
      background: #000;
      color: #fff;
      overflow: hidden;
    }
    /* Floating geometric shapes */
    .bo-hero-shape {
      position: absolute;
      border-radius: 50%;
      filter: blur(60px);
      opacity: .4;
      animation: float 8s ease-in-out infinite alternate;
    }
    @keyframes float {
      0% { transform: translate(0,0) scale(1); }
      100% { transform: translate(20px,-20px) scale(1.1); }
    }
    .bo-hero-inner {
      position: relative; z-index: 1;
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      gap: 48px;
    }
    .bo-hero-video {
      flex: 1;
      max-width: 480px;
      border-radius: 16px;
      overflow: hidden;
    }
    .bo-hero-video video {
      width: 100%;
      height: auto;
      display: block;
      border-radius: 16px;
    }
    .bo-hero-content {
      flex: 1;
    }
    @media (max-width: 900px) {
      .bo-hero-inner {
        flex-direction: column;
        text-align: center;
      }
      .bo-hero-video {
        max-width: 100%;
        order: -1;
      }
      .bo-hero-actions {
        justify-content: center;
      }
      .bo-hero-countdown-row {
        justify-content: center;
      }
    }
    .bo-hero-eyebrow {
      display: inline-flex; align-items: center; gap: 10px;
      padding: 8px 16px;
      background: rgba(255,255,255,.08);
      border: 1px solid rgba(255,255,255,.1);
      border-radius: 100px;
      font-family: 'Space Mono', monospace;
      font-size: 12px; font-weight: 700;
      text-transform: uppercase; letter-spacing: .12em;
      color: rgba(255,255,255,.7);
      margin-bottom: 28px;
    }
    .bo-hero-eyebrow-dot {
      width: 8px; height: 8px; border-radius: 50%;
      background: #F0B400;
      animation: blink 1.5s infinite;
    }
    @keyframes blink { 0%,100%{opacity:1;} 50%{opacity:.3;} }
    .bo-hero h1 {
      font-size: clamp(28px, 4.5vw, 52px);
      line-height: 1.1;
      font-weight: 800;
      letter-spacing: -.02em;
      margin-bottom: 24px;
    }
    .bo-hero h1 .teal { color: #84AE25; }
    .bo-hero h1 .yellow { color: #F0B400; }
    .bo-hero h1 .pink { color: #F691CA; }
    .bo-hero-sub {
      font-size: clamp(16px,2vw,20px);
      line-height: 1.6; color: rgba(255,255,255,.6);
      max-width: 540px; margin-bottom: 36px;
    }
    .bo-hero-actions {
      display: flex; flex-wrap: wrap; gap: 12px;
      align-items: center; margin-bottom: 40px;
    }
    .bo-btn-big {
      padding: 16px 32px;
      background: #F0B400; color: #000;
      font-family: 'Inter', sans-serif;
      font-size: 15px; font-weight: 700;
      border: none; border-radius: 8px;
      cursor: pointer; text-decoration: none;
      transition: all .2s;
      letter-spacing: -.01em;
    }
    .bo-btn-big:hover { background:#FFCA2B; transform:translateY(-2px); box-shadow: 0 8px 24px rgba(240,180,0,.3); }
    .bo-btn-ghost-w {
      padding: 16px 24px;
      color: rgba(255,255,255,.6); background: none;
      border: none; font-size: 15px; font-weight: 600;
      cursor: pointer; text-decoration: none;
      font-family: 'Nunito', sans-serif;
      transition: color .2s;
    }
    .bo-btn-ghost-w:hover { color:#fff; }
    .bo-hero-countdown-row {
      display: flex; align-items: center; gap: 16px; flex-wrap: wrap;
    }
    .bo-hero-countdown-label {
      font-family: 'Space Mono', monospace;
      font-size: 11px; color: rgba(255,255,255,.3);
      text-transform: uppercase; letter-spacing: .12em;
    }

    /* ── COLOR BAR ── */
    .bo-color-bar {
      display: flex; height: 6px;
    }
    .bo-color-bar div { flex: 1; }

    /* ── SECTION ── */
    .bo-pad { padding: clamp(48px,7vw,88px) clamp(16px,4vw,40px); }
    .bo-label {
      font-family: 'Space Mono', monospace;
      font-size: 11px; font-weight: 700;
      text-transform: uppercase; letter-spacing: .16em;
      margin-bottom: 10px;
    }
    .bo-h2 {
      font-size: clamp(26px,4.5vw,48px);
      line-height: 1.08; letter-spacing: -.02em;
      margin-bottom: 16px;
    }
    .bo-subdesc {
      font-size: 16px; line-height: 1.6; color: #888;
      max-width: 500px; margin-bottom: 40px;
    }

    /* ── COURSES ── */
    .bo-courses {
      display: flex; flex-direction: column; gap: 0;
      max-width: 1000px;
      margin: 0 auto;
    }
    .bo-course {
      display: grid;
      grid-template-columns: 100px 1fr auto;
      gap: 0;
      border-bottom: 2px solid #000;
      transition: background .3s;
      cursor: pointer;
      position: relative;
    }
    @media(max-width:700px) {
      .bo-course { grid-template-columns:1fr; }
    }
    .bo-course:hover { background: rgba(0,0,0,.02); }
    .bo-course-num-col {
      padding: 32px 20px;
      display: flex; align-items: flex-start;
      font-family: 'Inter', sans-serif;
      font-size: 56px; font-weight: 800;
      line-height: 1; color: rgba(0,0,0,.06);
      border-right: 2px solid #000;
    }
    @media(max-width:700px) { .bo-course-num-col { border-right:none; border-bottom:2px solid rgba(0,0,0,.06); padding:20px; font-size:40px; } }
    .bo-course-main {
      padding: 32px 28px;
    }
    .bo-course-hook {
      font-family: 'Space Mono', monospace;
      font-size: 11px; font-weight: 700;
      text-transform: uppercase; letter-spacing: .12em;
      margin-bottom: 8px;
    }
    .bo-course-title {
      font-family: 'Inter', sans-serif;
      font-size: clamp(20px,3vw,28px);
      font-weight: 700; letter-spacing: -.02em;
      margin-bottom: 10px;
    }
    .bo-course-desc {
      font-size: 15px; line-height: 1.6; color: #777;
      margin-bottom: 16px; max-width: 480px;
    }
    .bo-course-for {
      font-size: 13px; color: #aaa;
      font-style: italic; margin-bottom: 16px;
    }
    .bo-course-modules-wrap {
      overflow: hidden;
      transition: max-height .5s cubic-bezier(.16,1,.3,1);
    }
    .bo-course-mod {
      display: flex; align-items: center; gap: 10px;
      padding: 6px 0; font-size: 13px; color: #555;
    }
    .bo-course-mod-dot {
      width: 8px; height: 8px; border-radius: 2px;
      flex-shrink: 0;
    }
    .bo-course-cta-col {
      padding: 32px 28px;
      display: flex; flex-direction: column;
      align-items: flex-end; justify-content: center;
      gap: 8px;
      border-left: 2px solid #000;
    }
    @media(max-width:700px) { .bo-course-cta-col { border-left:none; align-items:flex-start; padding-top:0; } }
    .bo-course-price {
      font-family: 'Inter', sans-serif;
      font-size: 28px; font-weight: 800;
    }
    .bo-course-price-old {
      font-size: 14px; color: #ccc;
      text-decoration: line-through;
    }
    .bo-course-buy {
      padding: 10px 20px;
      font-size: 13px; font-weight: 700;
      border: 2px solid #000; background: none;
      border-radius: 6px; cursor: pointer;
      text-decoration: none; color: #000;
      font-family: 'Inter', sans-serif;
      transition: all .2s;
    }
    .bo-course-buy:hover { background:#000; color:#fff; }
    .bo-course-expand-btn {
      font-family: 'Space Mono', monospace;
      font-size: 11px; background: none; border: none;
      cursor: pointer; color: #aaa; text-transform: uppercase;
      letter-spacing: .1em; padding: 4px 0;
      transition: color .2s;
    }
    .bo-course-expand-btn:hover { color: #000; }

    /* ── PACKS ── */
    .bo-packs-bg {
      background: #F0B400;
      position: relative;
    }
    .bo-packs-bg::before {
      content: ''; position: absolute; top: 0; left: 0; right: 0;
      height: 6px; background: #000;
    }
    .bo-packs-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      max-width: 960px;
      margin: 0 auto;
    }
    @media(max-width:820px) { .bo-packs-grid { grid-template-columns:1fr; max-width:380px; } }
    .bo-pack {
      background: #fff;
      border: 3px solid #000;
      border-radius: 12px;
      padding: 28px 24px;
      display: flex; flex-direction: column;
      cursor: pointer;
      transition: transform .2s, box-shadow .2s;
      position: relative;
    }
    .bo-pack:hover { transform:translateY(-4px); box-shadow: 6px 6px 0 #000; }
    .bo-pack.selected {
      background: #000; color: #fff;
      transform: translateY(-4px);
      box-shadow: 6px 6px 0 #F0B400;
    }
    .bo-pack.selected .bo-pack-label { color: rgba(255,255,255,.4); }
    .bo-pack.selected .bo-pack-per { color: rgba(255,255,255,.4); }
    .bo-pack.selected .bo-pack-feat { color: rgba(255,255,255,.5); }
    .bo-pack-popular {
      position: absolute; top: -14px; right: 16px;
      background: #CD5096; color: #fff;
      font-family: 'Space Mono', monospace;
      font-size: 10px; font-weight: 700;
      text-transform: uppercase; letter-spacing: .1em;
      padding: 5px 12px; border-radius: 4px;
    }
    .bo-pack-label {
      font-family: 'Space Mono', monospace;
      font-size: 12px; font-weight: 700;
      text-transform: uppercase; letter-spacing: .12em;
      color: #999; margin-bottom: 16px;
    }
    .bo-pack-pct {
      font-family: 'Inter', sans-serif;
      font-size: 48px; font-weight: 800;
      line-height: 1; margin-bottom: 2px;
    }
    .bo-pack-pct-label {
      font-size: 12px; color: #aaa; margin-bottom: 12px;
      font-weight: 600;
    }
    .bo-pack-price {
      font-family: 'Inter', sans-serif;
      font-size: 28px; font-weight: 800;
      margin-bottom: 2px;
    }
    .bo-pack-per {
      font-size: 13px; color: #999; margin-bottom: 4px;
      font-family: 'Space Mono', monospace;
    }
    .bo-pack-orig {
      font-size: 13px; color: #ccc;
      text-decoration: line-through;
      margin-bottom: 20px;
    }
    .bo-pack-feats {
      flex: 1;
      display: flex; flex-direction: column; gap: 6px;
      margin-bottom: 24px;
    }
    .bo-pack-feat {
      font-size: 13px; color: #666; line-height: 1.4;
      display: flex; gap: 8px;
    }
    .bo-pack-btn-dark {
      display: block; width: 100%; text-align: center;
      padding: 14px; background: #000; color: #fff;
      font-family: 'Inter', sans-serif;
      font-size: 14px; font-weight: 700;
      border: none; border-radius: 8px;
      cursor: pointer; text-decoration: none;
      transition: all .15s;
    }
    .bo-pack-btn-dark:hover { background:#222; }
    .bo-pack.selected .bo-pack-btn-dark {
      background: #F0B400; color: #000;
    }
    .bo-pack.selected .bo-pack-btn-dark:hover { background:#FFCA2B; }
    .bo-pack-btn-outline {
      display: block; width: 100%; text-align: center;
      padding: 14px; background: none; color: #000;
      font-family: 'Inter', sans-serif;
      font-size: 14px; font-weight: 700;
      border: 2px solid #000; border-radius: 8px;
      cursor: pointer; text-decoration: none;
      transition: all .15s;
    }
    .bo-pack-btn-outline:hover { background:#000; color:#fff; }
    .bo-pack.selected .bo-pack-btn-outline {
      border-color: #fff; color: #fff;
    }
    .bo-pack.selected .bo-pack-btn-outline:hover { background:rgba(255,255,255,.1); }
    .bo-pack.selected .bo-pack-orig { color: rgba(255,255,255,.25); }

    /* ── TESTIMONIALS ── */
    .bo-test-row {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px; max-width: 1000px;
      margin: 0 auto;
    }
    @media(max-width:820px) { .bo-test-row { grid-template-columns:1fr; } }
    .bo-test {
      border: 3px solid #000;
      border-radius: 12px;
      overflow: hidden;
      transition: transform .2s, box-shadow .2s;
    }
    .bo-test:hover { transform:translateY(-3px); box-shadow: 5px 5px 0 #000; }
    .bo-test-top { padding: 24px; }
    .bo-test-stars {
      font-size: 16px; margin-bottom: 12px;
      letter-spacing: 2px;
    }
    .bo-test-quote {
      font-size: 16px; line-height: 1.55;
      font-weight: 600; color: #fff;
    }
    .bo-test-bottom {
      padding: 16px 24px;
      background: #fff;
      display: flex; align-items: center; gap: 12px;
      border-top: 3px solid #000;
    }
    .bo-test-avatar {
      width: 36px; height: 36px; border-radius: 50%;
      border: 2px solid #000;
      display: flex; align-items: center; justify-content: center;
      font-weight: 800; font-size: 14px;
      font-family: 'Inter', sans-serif;
    }
    .bo-test-name { font-weight: 700; font-size: 14px; }
    .bo-test-ctx { font-size: 12px; color: #999; }

    /* ── FAQ ── */
    .bo-faq { max-width: 640px; margin: 0 auto; }
    .bo-faq-item { border-bottom: 2px solid #000; }
    .bo-faq-q {
      width: 100%; display: flex; justify-content: space-between;
      align-items: center; padding: 18px 0;
      font-family: 'Inter', sans-serif; font-size: 15px; font-weight: 600;
      color: #000; background: none; border: none; cursor: pointer;
      text-align: left; gap: 12px; letter-spacing: -.01em;
    }
    .bo-faq-q:hover { color: #F0B400; }
    .bo-faq-icon {
      width: 28px; height: 28px; border-radius: 50%;
      border: 2px solid #000; display: flex;
      align-items: center; justify-content: center;
      font-size: 16px; flex-shrink: 0;
      transition: all .3s;
    }
    .bo-faq-a {
      overflow: hidden;
      transition: max-height .4s cubic-bezier(.16,1,.3,1), opacity .3s;
    }
    .bo-faq-a p { font-size: 14px; line-height: 1.65; color: #777; padding-bottom: 18px; }

    /* ── FINAL CTA ── */
    .bo-final {
      background: #000; color: #fff;
      text-align: center;
      position: relative; overflow: hidden;
    }
    .bo-final::before {
      content: '';
      position: absolute; inset: 0;
      background:
        radial-gradient(circle at 15% 50%, rgba(0,159,154,.2) 0%, transparent 50%),
        radial-gradient(circle at 85% 50%, rgba(205,80,150,.15) 0%, transparent 50%),
        radial-gradient(circle at 50% 80%, rgba(240,180,0,.1) 0%, transparent 50%);
    }

    /* ── FOOTER ── */
    .bo-footer {
      padding: 24px clamp(16px,4vw,40px);
      border-top: 3px solid #000;
      display: flex; flex-wrap: wrap; justify-content: space-between;
      align-items: center; gap: 16px;
      font-size: 12px; color: #aaa;
    }
    .bo-footer a { color:#888; text-decoration:none; font-weight:600; }
    .bo-footer a:hover { color:#000; }
  `;

  return (
    <>
      <style>{css}</style>
      <div className="bo">

        {/* NAV */}
        <nav className="bo-nav">
          <a href="#" className="bo-nav-logo">
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DIS_logo%20negro_v1-xJ8hf6JlwzMRzJi5Ia4ro2knDUEhMU.png" alt="Qelbe" style={{ height: 28 }} />
          </a>
          <div className="bo-nav-right">
            <a href="#metodos" className="bo-nav-link">Cursos Qelbe</a>
            <a href="#packs" className="bo-nav-link">Packs</a>
            <a href="#packs" className="bo-nav-cta">Inscribirme →</a>
          </div>
        </nav>

        {/* HERO */}
        <section className="bo-hero">
          {/* floating blobs */}
          <div className="bo-hero-shape" style={{ width: 400, height: 400, background: "#F0B400", top: "-10%", right: "-5%", animationDelay: "0s" }} />
          <div className="bo-hero-shape" style={{ width: 300, height: 300, background: "#E9781C", bottom: "-10%", left: "10%", animationDelay: "2s", animationDirection: "alternate-reverse" }} />
          <div className="bo-hero-shape" style={{ width: 250, height: 250, background: "#84AE25", top: "40%", right: "30%", animationDelay: "4s" }} />

          <div className="bo-hero-inner">
            <div className="bo-hero-content">
              <Reveal>
                <div className="bo-hero-eyebrow">
                  <span className="bo-hero-eyebrow-dot" />
                  Cursos Qelbe · Hasta 57% de descuento
                </div>
              </Reveal>
              <Reveal delay={.08}>
                <h1>
                  Deja de ir a ciegas<br />
                  en tu <span className="teal">negocio</span><br />
                  <span className="yellow">familiar</span>
                </h1>
              </Reveal>
              <Reveal delay={.16}>
                <p className="bo-hero-sub">
                  3 programas prácticos para dueños de MYPEs familiares que necesitan herramientas reales — no más teoría que no se aplica.
                </p>
              </Reveal>
              <Reveal delay={.24}>
                <div className="bo-hero-actions">
<a href="#packs" className="bo-btn-big">Ver packs desde $1,249/curso →</a>
                <a href="#cursos" className="bo-btn-ghost-w">Explorar los 3 cursos ↓</a>
                </div>
              </Reveal>
              <Reveal delay={.3}>
                <div className="bo-hero-countdown-row">
                  <span className="bo-hero-countdown-label">Cierre de inscripción</span>
                  <Countdown />
                </div>
              </Reveal>
            </div>
            <Reveal delay={.1}>
              <div className="bo-hero-video">
                <video autoPlay muted loop playsInline>
                  <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Qelbe-1T4DQKGwmt8uMx8x1RpKxOt8WoMdgA.mp4" type="video/mp4" />
                </video>
              </div>
            </Reveal>
          </div>
        </section>

        {/* COLOR BAR */}
        <div className="bo-color-bar">
          <div style={{ background: "#F0B400" }} />
          <div style={{ background: "#84AE25" }} />
          <div style={{ background: "#E9781C" }} />
          <div style={{ background: "#000" }} />
        </div>

        {/* COURSES */}
        <section className="bo-pad" id="metodos" style={{ background: "#fff" }}>
          <Reveal>
            <div className="bo-label" style={{ color: "#F0B400" }}>3 Cursos · 1 Sistema</div>
            <h2 className="bo-h2">Elige tu punto de partida<br />o llévate el sistema completo</h2>
            <p className="bo-subdesc">
              Cada curso es independiente pero se complementan. Juntos forman un sistema completo para la profesionalización de tu negocio familiar.
            </p>
          </Reveal>
          <div className="bo-courses" style={{ borderTop: "2px solid #000" }}>
            {courses.map((c, i) => (
              <Reveal key={c.id} delay={i * .06}>
                <div
                  className="bo-course"
                  onMouseEnter={() => setHoveredCourse(i)}
                  onMouseLeave={() => setHoveredCourse(null)}
                >
                  <div className="bo-course-num-col" style={{ color: hoveredCourse === i ? c.color : undefined, transition: "color .3s" }}>
                    {c.num}
                  </div>
                  <div className="bo-course-main">
                    <div className="bo-course-hook" style={{ color: c.color }}>{c.hook}</div>
                    <div className="bo-course-title">{c.title}</div>
                    <div className="bo-course-desc">{c.desc}</div>
                    <div className="bo-course-for">{c.forWho}</div>
                    <button
                      className="bo-course-expand-btn"
                      onClick={(e) => { e.stopPropagation(); setHoveredCourse(hoveredCourse === i ? null : i); }}
                    >
                      {hoveredCourse === i ? "▾ ocultar módulos" : "▸ ver módulos"}
                    </button>
                    <div className="bo-course-modules-wrap" style={{
                      maxHeight: hoveredCourse === i ? "300px" : "0",
                    }}>
                      <div style={{ paddingTop: 12 }}>
                        {c.modules.map((m, j) => (
                          <div className="bo-course-mod" key={j}>
                            <div className="bo-course-mod-dot" style={{ background: c.color }} />
                            <span>{m}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="bo-course-cta-col">
                    <div className="bo-course-price-old">$2,938</div>
                    <div className="bo-course-price" style={{ color: c.color }}>$1,469</div>
                    <a href={c.link} target="_blank" rel="noopener" className="bo-course-buy">
                      Comprar →
                    </a>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        {/* PACKS */}
        <section className="bo-pad bo-packs-bg" id="packs">
          <Reveal>
            <div className="bo-label" style={{ color: "#000" }}>Mejor en pack</div>
            <h2 className="bo-h2" style={{ color: "#000", maxWidth: 480, whiteSpace: "nowrap" }}>
              Cuantos más cursos, más ahorras
            </h2>
            <p className="bo-subdesc" style={{ color: "rgba(0,0,0,.5)" }}>
              El pack completo de 3 cursos sale a $1,249 por curso — 57% menos que el precio original.
            </p>
          </Reveal>
          <Reveal delay={.1}>
            <div className="bo-packs-grid">
              {packs.map((p) => (
                <div
                  key={p.key}
                  className={`bo-pack ${selectedPlan === p.key ? "selected" : ""}`}
                  onClick={() => setSelectedPlan(p.key)}
                  style={{ borderColor: p.courseColor }}
                >
                  {p.popular && <div className="bo-pack-popular">Más popular</div>}
                  <div className="bo-pack-label">{p.label}</div>
                  <div className="bo-pack-pct">{p.pct}</div>
                  <div className="bo-pack-pct-label">de descuento</div>
                  <div className="bo-pack-price">${p.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} <span style={{ fontSize: 14, fontWeight: 500 }}>MXN</span></div>
                  <div className="bo-pack-per">{p.perCourse}/curso</div>
                  <div className="bo-pack-orig">${p.original.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} MXN</div>
                  <div className="bo-pack-feats">
                    {p.key === "single" && (
                      <>
                        <div className="bo-pack-feat"><span>→</span> 1 curso a elegir</div>
                        <div className="bo-pack-feat"><span>→</span> ~12 horas de contenido</div>
                        <div className="bo-pack-feat"><span>→</span> 1 certificado</div>
                        <div className="bo-pack-feat"><span>→</span> 1 mes de acceso</div>
                      </>
                    )}
                    {p.key === "pack2" && (
                      <>
                        <div className="bo-pack-feat"><span>→</span> 2 cursos a elegir</div>
                        <div className="bo-pack-feat"><span>→</span> ~24 horas de contenido</div>
                        <div className="bo-pack-feat"><span>→</span> 2 certificados</div>
                        <div className="bo-pack-feat"><span>→</span> 1 mes por curso</div>
                      </>
                    )}
                    {p.key === "pack3" && (
                      <>
                        <div className="bo-pack-feat"><span>→</span> Los 3 cursos completos</div>
                        <div className="bo-pack-feat"><span>→</span> ~36 horas — sistema completo</div>
                        <div className="bo-pack-feat"><span>→</span> 3 certificados</div>
                        <div className="bo-pack-feat"><span>→</span> El mejor precio por curso</div>
                      </>
                    )}
                  </div>
                  {p.popular ? (
                    <a href="https://www.paypal.com/ncp/payment/CSTLA6U6PG5ZU" target="_blank" rel="noopener" className="bo-pack-btn-dark">
                      Inscribirme al pack completo →
                    </a>
                  ) : (
                    <a href={p.key === "single" ? "#metodos" : "https://www.paypal.com/ncp/payment/CSTLA6U6PG5ZU"} target={p.key === "single" ? "_self" : "_blank"} rel="noopener" className="bo-pack-btn-outline">
                      {p.key === "single" ? "Elegir mi curso" : "Elegir mis 2 cursos"}
                    </a>
                  )}
                </div>
              ))}
            </div>
          </Reveal>
          <div style={{ textAlign: "center", marginTop: 20, fontSize: 13, color: "rgba(0,0,0,.4)" }}>
            🔒 Pago seguro vía PayPal · Facturación disponible
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="bo-pad">
          <Reveal>
            <div className="bo-label" style={{ color: "#CD5096" }}>Graduados reales</div>
            <h2 className="bo-h2" style={{ marginBottom: 32 }}>Lo que dicen después del curso</h2>
          </Reveal>
          <Reveal delay={.1}>
            <div className="bo-test-row">
              {testimonials.map((t, i) => (
                <div className="bo-test" key={i}>
                  <div className="bo-test-top" style={{ background: t.color }}>
                    <div className="bo-test-stars">★★★★★</div>
                    <div className="bo-test-quote">{t.q}</div>
                  </div>
                  <div className="bo-test-bottom">
                    {t.img ? (
                      <img src={t.img} alt={t.name} className="bo-test-avatar" style={{ objectFit: "cover" }} />
                    ) : (
                      <div className="bo-test-avatar" style={{ background: t.color + "20", color: t.color }}>{t.name[0]}</div>
                    )}
                    <div>
                      <div className="bo-test-name">{t.name}</div>
                      <div className="bo-test-ctx">{t.ctx}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        </section>

        {/* FAQ */}
        <section className="bo-pad" style={{ background: "#fff" }}>
          <Reveal>
            <div className="bo-label" style={{ color: "#E9781C" }}>Dudas</div>
            <h2 className="bo-h2" style={{ marginBottom: 28 }}>Lo que necesitas saber</h2>
          </Reveal>
          <div className="bo-faq">
            {faqs.map((f, i) => (
              <div className="bo-faq-item" key={i}>
                <button className="bo-faq-q" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  <span>{f.q}</span>
                  <div className="bo-faq-icon" style={{
                    background: openFaq === i ? "#000" : "none",
                    color: openFaq === i ? "#fff" : "#000",
                    transform: openFaq === i ? "rotate(45deg)" : "rotate(0)",
                  }}>+</div>
                </button>
                <div className="bo-faq-a" style={{
                  maxHeight: openFaq === i ? "200px" : "0",
                  opacity: openFaq === i ? 1 : 0
                }}>
                  <p>{f.a}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* FINAL CTA */}
        <section className="bo-pad bo-final">
          <Reveal>
            <div style={{ position: "relative", zIndex: 1 }}>
              <h2 className="bo-h2" style={{ color: "#fff", textAlign: "center", margin: "0 auto 16px", whiteSpace: "nowrap" }}>
                Tu negocio familiar no puede<br />esperar otro año
              </h2>
              <p style={{ color: "rgba(255,255,255,.5)", textAlign: "center", fontSize: 16, marginBottom: 28, maxWidth: 400, margin: "0 auto 28px" }}>
                Los Cursos Qelbe completos desde $3,746 MXN. Packs con hasta 57% de descuento.
              </p>
              <div style={{ display: "flex", justifyContent: "center", gap: 12, flexWrap: "wrap", marginBottom: 28 }}>
                <a href="#packs" className="bo-btn-big">Ver packs y precios →</a>
              </div>
              <div style={{ display: "flex", justifyContent: "center" }}>
                <Countdown />
              </div>
            </div>
          </Reveal>
        </section>

        {/* COLOR BAR bottom */}
        <div className="bo-color-bar">
          <div style={{ background: "#E9781C" }} />
          <div style={{ background: "#84AE25" }} />
          <div style={{ background: "#F0B400" }} />
          <div style={{ background: "#000" }} />
        </div>

        {/* FOOTER */}
        <footer className="bo-footer">
          <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DIS_logo%20negro_v1-xJ8hf6JlwzMRzJi5Ia4ro2knDUEhMU.png" alt="Qelbe" style={{ height: 22 }} />
            <span>© Qelbe eLearning SL, Spain</span>
          </div>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <a href="https://www.qelbe.com/política-de-privacidad">Privacidad</a>
            <a href="https://www.qelbe.com/política-de-cookies">Cookies</a>
            <a href="https://www.qelbe.com/terminos-y-condiciones">Términos</a>
            <a href="mailto:hola@qelbe.com">hola@qelbe.com</a>
            <a href="tel:+525544992384">+52 554 499 2384</a>
          </div>
        </footer>
      </div>
    </>
  );
}
