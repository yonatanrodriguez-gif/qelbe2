import QelbeBold from "@/components/qelbe-bold"

export default function Page() {
  return <QelbeBold />
}
